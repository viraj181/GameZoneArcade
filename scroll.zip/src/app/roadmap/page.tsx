import React from "react";

function Roadmap() {
  return (
    <div className="bg-[--purple]  h-96">
      <div className="bg-[url('/img/road.svg')]">dd</div>
    </div>
  );
}

export default Roadmap;
